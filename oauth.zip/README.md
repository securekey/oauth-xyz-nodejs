# OAuthXYZ

A reference implementation for the OAuth.xyz protocol

Setup Instructions:

1. Clone the repository

2. Install npm modules

```
npm install
```

3. Run docker containers

```
docker-compose build
docker-compose up
```

4. For turning off, stop (and remove) docker containers

```
docker-compose stop
docker-compose rm # Optional
```
